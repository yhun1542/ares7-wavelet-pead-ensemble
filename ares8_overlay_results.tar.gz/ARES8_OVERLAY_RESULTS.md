# ARES8 v1 Overlay 백테스트 결과 분석

**실행 날짜**: 2024-12-01  
**베이스**: Equal-Weight Portfolio (100개 종목)  
**Overlay**: EPS Surprise PEAD (Horizon=5d, Budget=10%)  
**기간**: 2015-2025 (Train/Val/Test Split)  
**거래비용**: 0.1% (편도)

---

## ⚠️ **핵심 결론: PEAD Overlay 효과 없음 (음의 알파)**

EPS Surprise PEAD Overlay는 Equal-Weight 베이스 포트폴리오에 **음의 알파**를 추가했습니다.

---

## 📊 1. 전체 성능 비교

### All Period (2015-2025)

| 지표 | Base (EW) | Overlay (EW+PEAD) | Incremental | 해석 |
|------|-----------|-------------------|-------------|------|
| **Ann Return** | 15.4% | 14.6% | **-0.84%** | ⚠️ Overlay가 수익률 감소 |
| **Ann Vol** | 17.1% | 17.1% | 1.0% | 변동성 유사 |
| **Sharpe** | **0.902** | 0.856 | **-0.840** | ⚠️ Sharpe 감소 |
| **MDD** | -33.1% | -32.2% | -8.2% | MDD 약간 개선 |

**해석**:
- **Overlay가 Base보다 성능 저하** (Sharpe 0.902 → 0.856)
- **Incremental Sharpe -0.840** → 음의 알파
- **연간 수익률 -0.84%p 감소**

---

## 📈 2. Split별 성능 분석

### Train Period (2015-2018)

| 지표 | Base | Overlay | Incremental | 해석 |
|------|------|---------|-------------|------|
| **Ann Return** | 13.2% | 11.6% | **-1.65%** | ⚠️ 큰 폭 감소 |
| **Ann Vol** | 12.9% | 12.9% | 0.74% | 변동성 유사 |
| **Sharpe** | **1.028** | 0.898 | **-2.226** | ⚠️⚠️ 매우 큰 음의 알파 |
| **MDD** | -16.8% | -17.4% | -5.2% | MDD 악화 |

**Train 해석**:
- **Incremental Sharpe -2.226** → **매우 강한 음의 효과**
- **연간 수익률 -1.65%p 감소**
- PEAD Overlay가 Train에서 **역효과**

---

### Val Period (2019-2021)

| 지표 | Base | Overlay | Incremental | 해석 |
|------|------|---------|-------------|------|
| **Ann Return** | 26.4% | 26.2% | **-0.28%** | 약간 감소 |
| **Ann Vol** | 22.3% | 22.1% | 1.15% | 변동성 유사 |
| **Sharpe** | **1.187** | 1.184 | **-0.241** | 약한 음의 알파 |
| **MDD** | -33.1% | -32.2% | -3.0% | MDD 약간 개선 |

**Val 해석**:
- **Incremental Sharpe -0.241** → 약한 음의 효과
- **연간 수익률 -0.28%p 감소**
- Val에서도 Overlay 효과 없음

---

### Test Period (2022-2025)

| 지표 | Base | Overlay | Incremental | 해석 |
|------|------|---------|-------------|------|
| **Ann Return** | 8.6% | 7.9% | **-0.62%** | 감소 |
| **Ann Vol** | 15.4% | 15.5% | 1.05% | 변동성 유사 |
| **Sharpe** | **0.555** | 0.514 | **-0.590** | 음의 알파 |
| **MDD** | -20.4% | -20.6% | -2.6% | MDD 약간 악화 |

**Test 해석**:
- **Incremental Sharpe -0.590** → 음의 효과
- **연간 수익률 -0.62%p 감소**
- Out-of-Sample에서도 Overlay 효과 없음

---

## 🔍 3. 왜 Overlay가 역효과를 냈는가?

### 가설 1: **거래비용 (Turnover)**

PEAD Overlay는 이벤트 기반으로 빈번한 리밸런싱을 유발합니다.

- **Budget 10%**: 매 이벤트마다 10% 비중 재조정
- **Horizon 5d**: 평균 5일마다 포지션 변경
- **거래비용 0.1%**: 편도 10bp

**추정 연간 Turnover**:
- EPS 이벤트: 6,226개 / 10년 ≈ 623개/년
- 평균 활성 이벤트: ~10개 (동시 진행)
- 연간 Turnover: ~10% × 623 / 5 ≈ **1,246%**
- **연간 거래비용**: 1,246% × 0.1% × 2 (양방향) ≈ **2.5%**

**결론**: **거래비용이 PEAD 알파를 완전히 잠식**

---

### 가설 2: **Equal-Weight Base의 한계**

Equal-Weight는 **팩터 중립적**이지 않습니다.

- **Small-cap tilt**: 소형주 과대 비중
- **High volatility tilt**: 변동성 높은 종목 과대 비중
- **PEAD와의 상호작용**: EW가 이미 PEAD 효과를 일부 포함할 수 있음

**결론**: **진짜 ARES7 weight가 필요**

---

### 가설 3: **Budget 10%가 과도**

Budget 10%는 너무 공격적일 수 있습니다.

- **이벤트 단위 PEAD 효과**: 평균 초과수익 +0.16~0.78% (3~5일)
- **Budget 10%**: 10% × 0.5% ≈ **0.05%** (기대 수익)
- **거래비용**: ~0.1% (양방향)

**결론**: **기대 수익 < 거래비용** → 음의 알파

---

## 💡 4. 개선 방향

### ✅ **즉시 실행 가능한 개선**

#### 1. **Budget 축소** (10% → 3~5%)
- 거래비용 대비 기대 수익 비율 개선
- Turnover 감소

#### 2. **Horizon 연장** (5d → 10d)
- 포지션 유지 기간 증가 → Turnover 감소
- 거래비용 절감

#### 3. **거래비용 최적화**
- 0.1% → 0.05% (실제 거래비용 재측정)
- 또는 Turnover 제약 추가

#### 4. **진짜 ARES7 Base Weight 사용**
- Equal-Weight → ARES7 실제 weight
- 팩터 중립성 확보
- PEAD와의 상호작용 최소화

---

### 🔬 **추가 실험 필요**

#### 1. **Budget/Horizon Grid Search**

| Budget | Horizon | 예상 Turnover | 예상 거래비용 |
|--------|---------|---------------|---------------|
| 3% | 5d | ~375% | ~0.75% |
| 5% | 5d | ~625% | ~1.25% |
| 10% | 10d | ~625% | ~1.25% |
| 5% | 10d | ~312% | ~0.62% |

**권장**: Budget=5%, Horizon=10d

#### 2. **Turnover 제약 추가**
- 일별 최대 Turnover: 5%
- 월별 최대 Turnover: 20%

#### 3. **Signal Strength Threshold**
- 현재: surprise_rank > 0.8 (상위 20%)
- 개선: surprise_rank > 0.9 (상위 10%)
- 더 강한 시그널만 사용 → Turnover 감소

---

## 📋 5. 다음 단계

### Phase 1: **파라미터 최적화** (즉시 실행 가능)

```bash
# Budget=5%, Horizon=10d로 재실행
cd /home/ubuntu/ares7-ensemble
python -m research.pead.run_ares8_overlay --budget 0.05 --horizon 10
```

### Phase 2: **진짜 ARES7 Base Weight 사용**

1. ARES7 실제 weight CSV 생성
2. `/home/ubuntu/ares7-ensemble/data/ares7_base_weights.csv` 교체
3. 동일 파라미터로 재실행

### Phase 3: **Grid Search**

Budget × Horizon 조합 전체 테스트:
- Budget: [0.03, 0.05, 0.10, 0.15]
- Horizon: [3, 5, 10, 15]
- 총 16개 조합

---

## 🎯 6. 결론 및 권고사항

### ❌ **현재 설정 (Budget=10%, Horizon=5d)은 사용 불가**

- **Incremental Sharpe -0.840** (전체 기간)
- **Train Incremental Sharpe -2.226** (매우 큰 음의 알파)
- **거래비용이 PEAD 알파를 완전히 잠식**

### ⚠️ **Equal-Weight Base의 한계**

- Equal-Weight는 팩터 중립적이지 않음
- 진짜 ARES7 weight로 재실험 필요

### ✅ **개선 방향**

1. **Budget 축소**: 10% → 5%
2. **Horizon 연장**: 5d → 10d
3. **진짜 ARES7 Base Weight 사용**
4. **Grid Search로 최적 파라미터 탐색**

### 🚀 **즉시 실행 가능한 Next Step**

```bash
# Budget=5%, Horizon=10d로 재실행
python -m research.pead.run_ares8_overlay --budget 0.05 --horizon 10
```

---

## 📁 생성된 파일

### 결과 CSV 파일
1. **ares8_overlay_stats.csv** - Base/Overlay/Incremental 성능 통계
2. **ares8_overlay_base_ret.csv** - Base 일별 수익률
3. **ares8_overlay_overlay_ret.csv** - Overlay 일별 수익률
4. **ares8_overlay_incremental_ret.csv** - Incremental 일별 수익률

### 데이터 파일
- **ares7_base_weights.csv** - Equal-Weight Base Weights (247,190개 레코드)

### 패키지 구조
```
/home/ubuntu/ares7-ensemble/research/pead/
├── signal_builder.py ⭐ (EPS 이벤트 → 일별 시그널)
├── overlay_engine.py ⭐ (Base + Signal → Overlay Weight)
├── run_ares8_overlay.py ⭐ (엔드투엔드 백테스트)
├── build_equal_weight_base.py ⭐ (EW Base 생성)
├── ares8_overlay_run.log
└── (기존 PEAD v0/v1 파일들)
```

---

**작성자**: Manus AI  
**실행 환경**: Python 3.11, pandas, numpy  
**실행 시간**: ~2분 (Base Weight 생성 + Overlay 백테스트)
